require('dotenv').config();
const path = require('path');
const { connectToDatabase, closeDatabase, getDb } = require('../src/config/db');
const { parseCsv } = require('../src/utils/csvLoader');

const CSV_FILE_PATH = path.join(__dirname, '..', 'data', 'content.csv');
const BATCH_SIZE = 500;
const COLLECTION_NAME = 'content';

/**
 * Imports CSV data into MongoDB using bulkWrite for performance.
 * @param {string} csvPath - Path to the CSV file.
 * @param {string} collectionName - MongoDB collection name.
 * @param {number} batchSize - Number of documents per batch.
 */
async function importCsvToMongo(csvPath, collectionName, batchSize) {
  let db;
  try {
    // Initialize database connection
    await connectToDatabase();
    db = getDb();
    const collection = db.collection(collectionName);

    // Stream CSV rows
    const iterator = parseCsv(csvPath);
    let batch = [];
    let totalInserted = 0;

    // Process CSV rows
    for await (const row of iterator) {
      batch.push({ insertOne: { document: row } });

      // Execute batch when size is reached
      if (batch.length >= batchSize) {
        await collection.bulkWrite(batch, { ordered: false });
        totalInserted += batch.length;
        console.log(`Inserted ${totalInserted} documents...`);
        batch = [];
      }
    }

    // Process remaining documents
    if (batch.length > 0) {
      await collection.bulkWrite(batch, { ordered: false });
      totalInserted += batch.length;
      console.log(`Inserted ${totalInserted} documents (final).`);
    }

    console.log('CSV import completed successfully.');
  } catch (err) {
    console.error('CSV import failed:', err.message);
    throw err;
  } finally {
    await closeDatabase();
  }
}

/**
 * Main function to run the import script.
 */
(async () => {
  try {
    await importCsvToMongo(CSV_FILE_PATH, COLLECTION_NAME, BATCH_SIZE);
    process.exit(0);
  } catch (err) {
    process.exit(1);
  }
})();