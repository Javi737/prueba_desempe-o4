/**
 * scripts/importCsv.js
 *
 * Example script to bulk import `data/content.csv` into MongoDB using bulkWrite.
 * - Uses src/config/db.js connectToDatabase and getDb
 * - Uses csv loader to stream rows
 * - Batches inserts into bulkWrite ops for performance
 *
 * Run: node scripts/importCsv.js
 */
require('dotenv').config();
const path = require('path');
const { connectToDatabase, closeDatabase, getDb } = require('../src/config/db');
const { parseCsv } = require('../src/utils/csvLoader');

const CSV_PATH = path.join(__dirname, '..', 'data', 'content.csv');

(async () => {
  try {
    await connectToDatabase();
    const db = getDb();
    const iterator = parseCsv(CSV_PATH);
    const batchSize = 500;
    let batch = [];
    let count = 0;

    for await (const row of iterator) {
      // Use upsert by title+releaseYear to avoid duplicates if desired:
      batch.push({ insertOne: { document: row } });
      if (batch.length >= batchSize) {
        await db.collection('content').bulkWrite(batch);
        count += batch.length;
        console.log(`Inserted ${count} documents...`);
        batch = [];
      }
    }
    if (batch.length) {
      await db.collection('content').bulkWrite(batch);
      count += batch.length;
      console.log(`Inserted ${count} documents (final).`);
    }
    console.log('CSV import completed successfully.');
  } catch (err) {
    console.error('Import failed:', err);
  } finally {
    await closeDatabase();
    process.exit(0);
  }
})();
