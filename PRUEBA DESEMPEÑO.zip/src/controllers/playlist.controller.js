/**
 * src/controllers/playlist.controller.js
 *
 * Controllers for playlists, using src/models/playlists.js
 */
const Playlists = require('../models/playlists');

async function listPlaylists(req, res, next) {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const data = await Playlists.list({ page, limit });
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
}

async function getPlaylistById(req, res, next) {
  try {
    const doc = await Playlists.findById(req.params.id);
    if (!doc) return res.status(404).json({ success:false, error:{ message:'Playlist not found' }});
    res.json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
}

async function createPlaylist(req, res, next) {
  try {
    const payload = {
      userId: req.body.userId,
      name: req.body.name || 'Untitled Playlist',
      createdAt: new Date(),
      items: (req.body.items || []).map(i => i) // expect array of content ids (strings)
    };
    const created = await Playlists.create(payload);
    res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
}

async function updatePlaylist(req, res, next) {
  try {
    const allowed = ['name','items'];
    const updateObj = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updateObj[k] = req.body[k]; });
    const updated = await Playlists.update(req.params.id, updateObj);
    if (!updated) return res.status(404).json({ success:false, error:{ message:'Playlist not found' }});
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

async function deletePlaylist(req, res, next) {
  try {
    const removed = await Playlists.remove(req.params.id);
    if (!removed) return res.status(404).json({ success:false, error:{ message:'Playlist not found' }});
    res.json({ success: true, data: { message: 'Playlist deleted' }});
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/playlists/:id/items
 * Adds an item to a playlist using atomic $addToSet
 */
async function addItem(req, res, next) {
  try {
    const playlistId = req.params.id;
    const contentId = req.body.contentId;
    if (!contentId) return res.status(400).json({ success:false, error:{ message:'contentId required' }});
    const updated = await Playlists.addItem(playlistId, contentId);
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

async function removeItem(req, res, next) {
  try {
    const playlistId = req.params.id;
    const contentId = req.body.contentId;
    if (!contentId) return res.status(400).json({ success:false, error:{ message:'contentId required' }});
    const updated = await Playlists.removeItem(playlistId, contentId);
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

module.exports = { listPlaylists, getPlaylistById, createPlaylist, updatePlaylist, deletePlaylist, addItem, removeItem };
