/**
 * src/controllers/content.controller.js
 *
 * Controllers for content (movies & series).
 * Delegates DB operations to src/models/content.js
 */
const Content = require('../models/content');

async function listContent(req, res, next) {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const genre = req.query.genre;
    const year = req.query.year;
    const data = await Content.list({ page, limit, genre, year });
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
}

async function getContentById(req, res, next) {
  try {
    const doc = await Content.findById(req.params.id);
    if (!doc) return res.status(404).json({ success: false, error: { message: 'Content not found' } });
    res.json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
}

async function createContent(req, res, next) {
  try {
    // Basic validation
    if (!req.body.title) return res.status(400).json({ success: false, error: { message: 'title is required' }});
    const payload = {
      title: req.body.title,
      duration: req.body.duration ? parseInt(req.body.duration, 10) : null,
      releaseYear: req.body.releaseYear ? parseInt(req.body.releaseYear, 10) : null,
      genres: req.body.genres || [],
      cast: req.body.cast || [],
      reviews: []
    };
    const created = await Content.create(payload);
    res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
}

async function updateContent(req, res, next) {
  try {
    const allowed = ['title','duration','releaseYear','genres','cast'];
    const updateObj = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updateObj[k] = req.body[k]; });
    const updated = await Content.update(req.params.id, updateObj);
    if (!updated) return res.status(404).json({ success: false, error: { message: 'Content not found' }});
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

async function deleteContent(req, res, next) {
  try {
    const removed = await Content.remove(req.params.id);
    if (!removed) return res.status(404).json({ success: false, error: { message: 'Content not found' }});
    res.json({ success: true, data: { message: 'Content deleted' }});
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/content/:id/reviews
 * Adds a review to a content item.
 */
async function addReview(req, res, next) {
  try {
    const contentId = req.params.id;
    const { userId, rating, comment } = req.body;
    if (!userId || !rating) return res.status(400).json({ success:false, error:{ message:'userId and rating required' }});
    if (rating < 1 || rating > 5) return res.status(400).json({ success:false, error:{ message:'rating must be 1-5' }});
    const updated = await Content.addReview(contentId, { userId, rating, comment });
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/content/top-rated
 * Returns top N content by average rating
 */
async function topRated(req, res, next) {
  try {
    const limit = parseInt(req.query.limit) || 5;
    const data = await Content.getTopByAverageRating(limit);
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
}

module.exports = { listContent, getContentById, createContent, updateContent, deleteContent, addReview, topRated };
