/**
 * src/controllers/user.controller.js
 *
 * Controller layer for user-related endpoints.
 * Each function receives Express req/res and delegates DB work to src/models/users.js
 */
const Users = require('../models/users');
const { ObjectId } = require('mongodb');

/**
 * GET /api/users
 * Supports pagination via query params: ?page=1&limit=20
 */
async function getUsers(req, res, next) {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const data = await Users.findAll({ page, limit });
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/users/:id
 */
async function getUserById(req, res, next) {
  try {
    const user = await Users.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, error: { message: 'User not found' } });
    res.json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/users
 */
async function createUser(req, res, next) {
  try {
    const payload = {
      name: req.body.name,
      email: req.body.email,
      country: req.body.country || null,
      preferredGenres: req.body.preferredGenres || [],
      viewHistory: [],
      playlists: []
    };
    const user = await Users.create(payload);
    res.status(201).json({ success: true, data: user });
  } catch (err) {
    // Handle duplicate email error from unique index
    if (err.code === 11000) {
      return res.status(409).json({ success: false, error: { message: 'Email already exists' } });
    }
    next(err);
  }
}

/**
 * PUT /api/users/:id
 */
async function updateUser(req, res, next) {
  try {
    const allowed = ['name', 'country', 'preferredGenres'];
    const updateObj = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updateObj[k] = req.body[k]; });
    const updated = await Users.update(req.params.id, updateObj);
    if (!updated) return res.status(404).json({ success: false, error: { message: 'User not found' } });
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/users/:id
 */
async function deleteUser(req, res, next) {
  try {
    const removed = await Users.remove(req.params.id);
    if (!removed) return res.status(404).json({ success: false, error: { message: 'User not found' } });
    res.json({ success: true, data: { message: 'User deleted' } });
  } catch (err) {
    next(err);
  }
}

module.exports = { getUsers, getUserById, createUser, updateUser, deleteUser };
