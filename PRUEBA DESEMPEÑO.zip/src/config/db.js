/**
 * src/config/db.js
 *
 * Connects to MongoDB using the native MongoDB driver.
 * Exports:
 * - connectToDatabase(): initialize connection and set globals
 * - getDb(): return the active database instance
 *
 * Design notes:
 * - We create a single MongoClient and reuse it across the app.
 * - For scripts (like importCsv.js) you can call connectToDatabase() as well.
 */
const { MongoClient } = require('mongodb');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/streamhub';
const DB_NAME = (new URL(MONGO_URI)).pathname.replace('/', '') || 'streamhub'; // fallback

let client;
let db;

/**
 * connectToDatabase()
 * Establishes a connection to MongoDB and caches client & db references.
 * Returns a promise that resolves when connected.
 */
async function connectToDatabase() {
  if (db) {
    // already connected
    return { client, db };
  }
  // Create a new MongoClient with recommended settings
  client = new MongoClient(MONGO_URI, {
    serverSelectionTimeoutMS: 5000,
    // other options can be set here (tls, poolSize, etc.)
  });

  // Connect the client
  await client.connect();
  db = client.db(DB_NAME);

  // Example: ensure some basic indexes on start-up (idempotent)
  await db.collection('users').createIndex({ email: 1 }, { unique: true });
  await db.collection('content').createIndex({ title: 1 });
  await db.collection('content').createIndex({ genres: 1 });
  await db.collection('playlists').createIndex({ userId: 1 });

  console.log('✅ Connected to MongoDB (native driver). DB:', DB_NAME);
  return { client, db };
}

/**
 * getDb()
 * Returns the database object; throws if not connected.
 */
function getDb() {
  if (!db) throw new Error('Database not connected. Call connectToDatabase() first.');
  return db;
}

/**
 * closeDatabase()
 * Gracefully close the MongoDB client connection.
 */
async function closeDatabase() {
  if (client) {
    await client.close();
    client = null;
    db = null;
  }
}

module.exports = { connectToDatabase, getDb, closeDatabase };
