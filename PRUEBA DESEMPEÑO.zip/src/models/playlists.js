/**
 * src/models/playlists.js
 *
 * Data access functions for playlists collection.
 * Playlists store references to content by ObjectId in `items` array.
 */
const { getDb } = require('../config/db');
const { ObjectId } = require('mongodb');

async function list({ page = 1, limit = 20 } = {}) {
  const db = getDb();
  const skip = (page - 1) * limit;
  const items = await db.collection('playlists').find({}).skip(skip).limit(limit).toArray();
  const total = await db.collection('playlists').countDocuments();
  return { items, total };
}

async function findById(id) {
  const db = getDb();
  return db.collection('playlists').findOne({ _id: new ObjectId(id) });
}

async function create(playlistObj) {
  const db = getDb();
  const res = await db.collection('playlists').insertOne(playlistObj);
  return { _id: res.insertedId, ...playlistObj };
}

async function update(id, updateObj) {
  const db = getDb();
  const res = await db.collection('playlists').findOneAndUpdate(
    { _id: new ObjectId(id) },
    { $set: updateObj },
    { returnDocument: 'after' }
  );
  return res.value;
}

async function remove(id) {
  const db = getDb();
  const res = await db.collection('playlists').deleteOne({ _id: new ObjectId(id) });
  return res.deletedCount === 1;
}

/**
 * addItem(playlistId, contentId)
 * Uses $addToSet to avoid duplicate entries of the same content
 */
async function addItem(playlistId, contentId) {
  const db = getDb();
  await db.collection('playlists').updateOne(
    { _id: new ObjectId(playlistId) },
    { $addToSet: { items: new ObjectId(contentId) } }
  );
  return findById(playlistId);
}

/**
 * removeItem(playlistId, contentId)
 */
async function removeItem(playlistId, contentId) {
  const db = getDb();
  await db.collection('playlists').updateOne(
    { _id: new ObjectId(playlistId) },
    { $pull: { items: new ObjectId(contentId) } }
  );
  return findById(playlistId);
}

module.exports = { list, findById, create, update, remove, addItem, removeItem };
