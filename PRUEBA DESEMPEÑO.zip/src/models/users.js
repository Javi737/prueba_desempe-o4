/**
 * src/models/users.js
 *
 * Data access layer for the 'users' collection using native MongoDB driver.
 * Each exported function performs a small, single-responsibility DB operation.
 *
 * Note: these functions expect connectToDatabase() to have been called
 * during application startup so getDb() returns a live DB instance.
 */
const { getDb } = require('../config/db');
const { ObjectId } = require('mongodb');

/**
 * findAll({ page, limit })
 * - Returns paginated users. Do not return entire viewHistory by default if large.
 */
async function findAll({ page = 1, limit = 20 } = {}) {
  const db = getDb();
  const skip = (page - 1) * limit;
  // projection excludes potentially large fields by default (adjust as needed)
  const cursor = db.collection('users').find({}, { projection: { viewHistory: 0 } }).skip(skip).limit(limit);
  const users = await cursor.toArray();
  const total = await db.collection('users').countDocuments();
  return { users, total };
}

/**
 * findById(id)
 * - Returns a single user document by ObjectId string.
 */
async function findById(id) {
  const db = getDb();
  return db.collection('users').findOne({ _id: new ObjectId(id) });
}

/**
 * create(userObj)
 * - Inserts a new user document. Expects email uniqueness enforced by index.
 */
async function create(userObj) {
  const db = getDb();
  const result = await db.collection('users').insertOne(userObj);
  return result.ops ? result.ops[0] : { _id: result.insertedId, ...userObj };
}

/**
 * update(id, updateObj)
 * - Performs a partial update and returns the updated document.
 */
async function update(id, updateObj) {
  const db = getDb();
  const result = await db.collection('users').findOneAndUpdate(
    { _id: new ObjectId(id) },
    { $set: updateObj },
    { returnDocument: 'after' }
  );
  return result.value;
}

/**
 * remove(id)
 * - Deletes a user by id.
 */
async function remove(id) {
  const db = getDb();
  const result = await db.collection('users').deleteOne({ _id: new ObjectId(id) });
  return result.deletedCount === 1;
}

module.exports = { findAll, findById, create, update, remove };
