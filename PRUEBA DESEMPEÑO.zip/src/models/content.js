/**
 * src/models/content.js
 *
 * Data access layer for the 'content' collection.
 * Implements functions to query content, add reviews, and compute aggregated values.
 */
const { getDb } = require('../config/db');
const { ObjectId } = require('mongodb');

/**
 * list({ page, limit, genre, year })
 * - Basic list with optional filters. For minRating, use getTopByRating or aggregation.
 */
async function list({ page = 1, limit = 20, genre, year } = {}) {
  const db = getDb();
  const skip = (page - 1) * limit;
  const filter = {};
  if (genre) filter.genres = genre;
  if (year) filter.releaseYear = parseInt(year, 10);
  const cursor = db.collection('content').find(filter).skip(skip).limit(limit);
  const items = await cursor.toArray();
  const total = await db.collection('content').countDocuments(filter);
  return { items, total };
}

async function findById(id) {
  const db = getDb();
  return db.collection('content').findOne({ _id: new ObjectId(id) });
}

async function create(contentObj) {
  const db = getDb();
  const res = await db.collection('content').insertOne(contentObj);
  return { _id: res.insertedId, ...contentObj };
}

async function update(id, updateObj) {
  const db = getDb();
  const res = await db.collection('content').findOneAndUpdate(
    { _id: new ObjectId(id) },
    { $set: updateObj },
    { returnDocument: 'after' }
  );
  return res.value;
}

async function remove(id) {
  const db = getDb();
  const res = await db.collection('content').deleteOne({ _id: new ObjectId(id) });
  return res.deletedCount === 1;
}

/**
 * addReview(contentId, review)
 * - Appends a review object to the reviews array using $push to avoid race conditions.
 * - review should be { userId: string, rating: number, comment: string }
 */
async function addReview(contentId, review) {
  const db = getDb();
  const reviewObj = {
    userId: new ObjectId(review.userId),
    rating: review.rating,
    comment: review.comment,
    createdAt: new Date()
  };
  await db.collection('content').updateOne(
    { _id: new ObjectId(contentId) },
    { $push: { reviews: reviewObj } }
  );
  // return updated doc
  return findById(contentId);
}

/**
 * getTopByAverageRating(limit = 5)
 * - Aggregation that computes average rating per content and returns top N.
 */
async function getTopByAverageRating(limit = 5) {
  const db = getDb();
  const pipeline = [
    { $unwind: '$reviews' },
    { $group: { _id: '$_id', title: { $first: '$title' }, avgRating: { $avg: '$reviews.rating' } } },
    { $sort: { avgRating: -1 } },
    { $limit: limit }
  ];
  return db.collection('content').aggregate(pipeline).toArray();
}

module.exports = { list, findById, create, update, remove, addReview, getTopByAverageRating };
