/**
 * src/app.js
 *
 * Main Express application entrypoint.
 * Uses the native MongoDB driver for database operations via src/config/db.js
 *
 * Responsibilities:
 * - Load environment variables
 * - Connect to MongoDB once and reuse the client/db across requests
 * - Configure middleware (JSON parser, CORS, security headers, logging)
 * - Mount route modules
 * - Global error handling and graceful shutdown listeners
 */
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');

const { connectToDatabase } = require('./config/db');
const userRoutes = require('./routes/user.routes');
const contentRoutes = require('./routes/content.routes');
const playlistRoutes = require('./routes/playlist.routes');

const app = express();

// Middlewares: body parsing, security headers, CORS and logging
app.use(express.json()); // parse application/json
app.use(helmet()); // set secure headers
app.use(cors()); // enable CORS (configure origin in production)
app.use(morgan('dev')); // request logging in dev

// Mount API routes under /api
app.use('/api/users', userRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/playlists', playlistRoutes);

// Simple health check route
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Global error handler - keeps error responses consistent
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: { message: err.message || 'Internal Server Error' }
  });
});

// Start server after DB connection
const PORT = process.env.PORT || 3000;
connectToDatabase() // connectToDatabase returns a Promise that resolves when connected
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 StreamHub API (native MongoDB) running on port ${PORT}`);
    });
  })
  .catch(err => {
    console.error('Failed to connect to DB', err);
    process.exit(1); // fail fast if DB connection fails
  });

// Handle unexpected rejections and exceptions for graceful shutdown in production
process.on('unhandledRejection', (reason) => {
  console.error('Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});
