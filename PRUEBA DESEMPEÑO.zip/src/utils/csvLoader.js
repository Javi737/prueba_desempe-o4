/**
 * src/utils/csvLoader.js
 *
 * Small helper that parses a CSV file into content objects.
 * Uses 'csv-parser' package which emits row events.
 *
 * Expected CSV header:
 * title,duration,releaseYear,genres,cast
 *
 * Sub-fields (genres, cast) should be pipe-separated inside the cell:
 * e.g. "Science Fiction|Drama".
 *
 * The function export returns an async iterator for backpressure-friendly streaming imports.
 */
const fs = require('fs');
const csv = require('csv-parser');

/**
 * async function parseCsv(filePath)
 * Yields each parsed and transformed row as an object ready to insert into 'content' collection.
 */
async function* parseCsv(filePath) {
  const stream = fs.createReadStream(filePath).pipe(csv());
  const iterator = stream[Symbol.asyncIterator]();

  try {
    while (true) {
      const { value, done } = await iterator.next();
      if (done) break;
      // Transform row: split pipe-separated fields and parse ints
      const row = {
        title: value.title,
        duration: value.duration ? parseInt(value.duration, 10) : null,
        releaseYear: value.releaseYear ? parseInt(value.releaseYear, 10) : null,
        genres: value.genres ? value.genres.split('|').map(s => s.trim()).filter(Boolean) : [],
        cast: value.cast ? value.cast.split('|').map(s => s.trim()).filter(Boolean) : [],
        reviews: []
      };
      yield row;
    }
  } finally {
    // ensure stream is closed
    stream.destroy();
  }
}

module.exports = { parseCsv };
