/**
 * src/routes/playlist.routes.js
 *
 * Express router for playlist endpoints.
 */
const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/playlist.controller');

router.get('/', ctrl.listPlaylists);
router.get('/:id', ctrl.getPlaylistById);
router.post('/', ctrl.createPlaylist);
router.put('/:id', ctrl.updatePlaylist);
router.delete('/:id', ctrl.deletePlaylist);
router.post('/:id/items', ctrl.addItem);
router.delete('/:id/items', ctrl.removeItem);

module.exports = router;
