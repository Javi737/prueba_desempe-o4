/**
 * src/routes/user.routes.js
 *
 * Express router for user endpoints. Maps HTTP methods & paths to controller functions.
 */
const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/user.controller');

router.get('/', ctrl.getUsers);
router.get('/:id', ctrl.getUserById);
router.post('/', ctrl.createUser);
router.put('/:id', ctrl.updateUser);
router.delete('/:id', ctrl.deleteUser);

module.exports = router;
