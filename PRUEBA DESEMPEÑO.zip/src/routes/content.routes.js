/**
 * src/routes/content.routes.js
 *
 * Express router for content endpoints.
 */
const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/content.controller');

router.get('/', ctrl.listContent);
router.get('/top-rated', ctrl.topRated);
router.get('/:id', ctrl.getContentById);
router.post('/', ctrl.createContent);
router.put('/:id', ctrl.updateContent);
router.delete('/:id', ctrl.deleteContent);
router.post('/:id/reviews', ctrl.addReview);

module.exports = router;
