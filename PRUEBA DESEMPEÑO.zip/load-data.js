const fs = require('fs');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function loadData() {
  const pool = mysql.createPool({ /* same config */ });
  // Parse the provided text data (in real, read from CSV)
  // For demo, assume data is array of objects from parsed rows
  const data = []; // Parse row2 to row101 here, e.g., data.push({ txn_id: 'TXN001', ... })

  for (const row of data) {
    const datetime = new Date(1900, 0, Math.floor(row.serial_date) - 1 + (row.serial_date % 1));
    // Insert customer if not exists
    await pool.query('INSERT IGNORE INTO customers VALUES (?, ?, ?, ?, ?)', [row.id_num, row.name, row.address, row.phone, row.email]);
    // Insert invoice
    await pool.query('INSERT INTO invoices VALUES (?, ?, ?, ?)', [row.invoice_num, row.period, row.billed, row.id_num]);
    // Insert transaction
    await pool.query('INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?)', [row.txn_id, datetime, row.trans_amt, row.status, row.platform, row.paid_amt, row.invoice_num]);
  }
  console.log('Data loaded');
  process.exit();
}

loadData(); 