require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(cors());

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

// CRUD for Customers
app.get('/customers', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM customers');
  res.json(rows);
});

app.post('/customers', async (req, res) => {
  const { identification_number, name, address, phone, email } = req.body;
  if (!identification_number || !name || !address || !phone || !email) return res.status(400).json({ error: 'Missing fields' });
  try {
    await pool.query('INSERT INTO customers VALUES (?, ?, ?, ?, ?)', [identification_number, name, address, phone, email]);
    res.status(201).json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/customers/:id', async (req, res) => {
  const { name, address, phone, email } = req.body;
  try {
    await pool.query('UPDATE customers SET name=?, address=?, phone=?, email=? WHERE identification_number=?', [name, address, phone, email, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/customers/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM customers WHERE identification_number=?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Advanced Queries
app.get('/queries/total-paid', async (req, res) => {
  const [rows] = await pool.query('SELECT c.name, SUM(t.paid_amount) AS total_paid FROM customers c JOIN invoices i ON c.identification_number = i.customer_identification JOIN transactions t ON i.invoice_number = t.invoice_number GROUP BY c.identification_number');
  res.json(rows);
});

app.get('/queries/pending-invoices', async (req, res) => {
  const [rows] = await pool.query('SELECT i.invoice_number, c.name, t.transaction_id, i.billed_amount, t.paid_amount, t.status FROM invoices i JOIN customers c ON i.customer_identification = c.identification_number JOIN transactions t ON i.invoice_number = t.invoice_number WHERE t.paid_amount < i.billed_amount OR t.status = "Pendiente"');
  res.json(rows);
});

app.get('/queries/transactions-by-platform', async (req, res) => {
  const { platform } = req.query;
  if (!platform) return res.status(400).json({ error: 'Platform required' });
  const [rows] = await pool.query('SELECT t.transaction_id, t.platform, c.name, i.invoice_number FROM transactions t JOIN invoices i ON t.invoice_number = i.invoice_number JOIN customers c ON i.customer_identification = c.identification_number WHERE t.platform = ?', [platform]);
  res.json(rows);
});

app.listen(process.env.PORT, () => console.log(`Server running on port ${process.env.PORT}`));